---
title: About me
author: Joaquin Garay
date: 2024-01-04
category: home
layout: post
---

You can reach me in my [LinkedIn Profile][1].

[1]: https://www.linkedin.com/in/garayjoaquin


